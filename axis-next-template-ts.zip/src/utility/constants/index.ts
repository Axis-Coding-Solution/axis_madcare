/**
 *
 * All constants that will be used in the app will defined and exported from here
 * For example Icons sizes, debounce time, etc.
 */
