/**
 *
 ** this file is entry point the all types that will be used in the app.
 ** create a type file for each module or page and import it from here to serve the app.
 *
 */

import { ReactNode } from "react";

export type LayoutPropsType = {
  children: ReactNode;
};
