/**
 *
 ** this file is entry point the all interfaces that will be used in the app.
 ** create a interface file for each module or page and import it from here to serve the app.
 *
 */
