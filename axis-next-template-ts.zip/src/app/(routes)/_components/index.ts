/**
 ** this directory contains all the components for the app that each page required distinctly.
 ** re-usable components would be added in the root components directory.
 */